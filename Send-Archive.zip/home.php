<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>Sarafina International School</title>
</head>

<body>
<div id="content">
	<div >
    	<img src="picture/pi.jpg" width="805" height="308"  />
    </div>
    
    <div id="space"></div>
    
    <div id="question">
    	What do you know about Sarafina International School?
    </div>
    
    <div id="space"></div>
    
    <div style="text-indent:40px; text-align:justify">
     Sarafina School is one of the best schools in Zambia. In the one-hundred years schooling, we adhere to the motto of Knowledge, Truth and Virtue.
     It is committed to educate talents with a solid foundation of knowledge and skills, with a strong sense of responsibility and commitment to the society.
   </br>The School seeks to integrate social service into its schooling. It equips itself with various disciplines, renowned scholars, innovative teams, advanced teaching and experimental facilities, and high-quality teaching resources.</br> Lying in Yangtze River Delta, one of the most developed areas in China. The university offers important support of talents, science and technology to the area's the economic and social development and even the whole country.

  </div>
</div><!--end of content -->
</body>
</html>